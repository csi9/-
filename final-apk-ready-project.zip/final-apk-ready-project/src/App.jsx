export default function App() {
  return (
    <div className="container">
      <h1>نظام كاشير نادي الرماية</h1>

      <div className="card">
        <h2>جاهز للتحويل إلى APK</h2>

        <ul>
          <li>واجهة React تعمل</li>
          <li>إعداد Capacitor جاهز</li>
          <li>جاهز للربط مع Android Studio</li>
          <li>قابل للبناء كتطبيق أندرويد</li>
        </ul>

        <button>فتح النظام</button>
      </div>
    </div>
  )
}