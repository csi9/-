# APK Ready Project

## التشغيل

npm install
npm run dev

## بناء المشروع

npm run build

## إنشاء أندرويد

npm run android:add

## مزامنة

npm run android:sync

## فتح Android Studio

npm run android:open

ثم Build APK من Android Studio.